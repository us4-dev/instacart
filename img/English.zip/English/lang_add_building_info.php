<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Add/Update Building Information";
$_data['text_2'] 		= "Building";
$_data['text_3'] 		= "Building Info";
$_data['text_4'] 		= "Building Information";
$_data['text_5'] 		= "Name";
$_data['text_6'] 		= "Address";
$_data['text_7'] 		= "Security Guard Mobile";
$_data['text_8'] 		= "Secretary Mobile";
$_data['text_9'] 		= "Moderator Mobile";
$_data['text_10'] 		= "Building Construction Year";
$_data['text_11'] 		= "Builder Information";
$_data['text_12'] 		= "Phone";
$_data['text_13'] 		= "Building Image";
$_data['text_14'] 		= "Select Year";

$_data['text_15'] 		= "Building Rules";
$_data['text_16'] 		= "Apartment Rules";

$_data['success_text'] 	= "Success";
$_data['update_text'] 	= "Updated building information successfully";

$_data['r1'] 			= "Building Name is Required !!";
$_data['r2'] 			= "Building Address Required !!!";
$_data['r3'] 			= "Building Security Guard Mobile No Required !!!";
$_data['r4'] 			= "Building Secratary Mobile No Required !!!";
$_data['r5'] 			= "Building Moderator Mobile No is Required !!!";
$_data['r6'] 			= "Building Construction Year Required !!!";
$_data['r7'] 			= "Builder Name is Required !!!";
$_data['r8'] 			= "Builder Address Required !!!";
$_data['r9'] 			= "Builder Mobile No Required !!!";

?>