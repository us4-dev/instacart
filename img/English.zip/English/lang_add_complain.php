<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Add New Complain";
$_data['text_1_1'] 		= "Update Complain";
$_data['text_2'] 		= "Complain";
$_data['text_3'] 		= "Add Complain";
$_data['text_4'] 		= "Complain Entry Form";
$_data['text_5'] 		= "Title";
$_data['text_6'] 		= "Description";
$_data['text_7'] 		= "Date";
$_data['text_8'] 		= "Added Complain Successfully";
$_data['text_9'] 		= "Updated Complain Successfully";
$_data['text_10'] 		= "Deleted Complain Successfully";

$_data['r1'] 			= "Complain Title Required !!!";
$_data['r2'] 			= "Complain Details Required !!!";
$_data['r3'] 			= "Complain Date Required !!!";


//tenant complain
$_data['t_text_1'] 		= "Add Tenant Complain";
?>