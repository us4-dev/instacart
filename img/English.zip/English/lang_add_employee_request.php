<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 				= "Add New Leave Rerquest";
$_data['text_1_1'] 				= "Update Leave Request";
$_data['text_2'] 				= "Leave request";
$_data['text_3'] 				= "Add New Leave Rerquest";
$_data['text_4'] 				= "Leave Rerquest Entry Form";
$_data['text_5'] 				= "Leave From";
$_data['text_leave_to'] 		= "Leave To";
$_data['text_leave_to'] 		= "Leave To";
$_data['text_6'] 				= "Leave Reason Description";
$_data['text_7'] 				= "Date";

$_data['r1'] 					= "Leave request from date required !!!";
$_data['r2'] 					= "Leave request to date required !!!";
$_data['r3'] 					= "Leave request reason description required !!!";


//tenant complain
$_data['t_text_1'] 				= "Leave Rerquest";
?>