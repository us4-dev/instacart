<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Add Meeting Information";
$_data['text_2'] 		= "Meeting";
$_data['text_3'] 		= "Add Meeting";
$_data['text_4'] 		= "Meeting Entry Form";
$_data['text_5'] 		= "Meeting Issue Date";
$_data['text_6'] 		= "Meeting Title";
$_data['text_66'] 		= "Meeting Description";
$_data['text_15'] 		= "Added Meeting Information Successfully";
$_data['text_16'] 		= "Update Meeting";
$_data['text_17'] 		= "Updated Meeting Information Successfully";

//validation
$_data['v1'] 			= "Meeting Issue Date Required !!!";
$_data['v2'] 			= "Meeting Title Required !!!";
$_data['v3'] 			= "Meeting Description Required !!!";
?>