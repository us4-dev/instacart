<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Bill Report";
$_data['text_2'] 		= "Bill Type";
$_data['text_3'] 		= "Date";
$_data['text_4'] 		= "Month";
$_data['text_5'] 		= "Year";
$_data['text_6'] 		= "Tatal Amount";
$_data['text_7'] 		= "Deposit Bank";
$_data['text_8'] 		= "Details";

?>