<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Currency Setup";
$_data['text_2'] 		= "Currency Entry Form";
$_data['text_3'] 		= "Symbol";
$_data['text_33'] 		= "Name";
$_data['text_4'] 		= "Currency List";
$_data['text_5'] 		= "Added Currency Information Successfully";
$_data['text_6'] 		= "Updated Currency Information Successfully";
$_data['text_7'] 		= "Deleted Currency Information Successfully";
$_data['text_8'] 		= "Currency Details";

//validation
$_data['required_1'] 		= "Currency symbol required !!!";
$_data['required_2'] 		= "Currency name required !!!";
$_data['confirm_delete'] 	= "Are you sure you want to delete this Currency ?";

?>