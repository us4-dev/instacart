<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Employee Salary Report";
$_data['text_2'] 		= "Issue Date";
$_data['text_3'] 		= "Name";
$_data['text_4'] 		= "Designation";
$_data['text_5'] 		= "Salary Month";
$_data['text_6'] 		= "Salary Year";
$_data['text_7'] 		= "Salary";
$_data['text_15'] 		= "Total";
$_data['text_16'] 		= "Print Information";


?>