<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Rent Collection Report";
$_data['text_2'] 		= "Date";
$_data['text_3'] 		= "Name";
$_data['text_4'] 		= "Type";
$_data['text_5'] 		= "Floor";
$_data['text_6'] 		= "Unit";
$_data['text_7'] 		= "Month";
$_data['text_77'] 		= "Year";
$_data['text_8'] 		= "Rent";
$_data['text_9'] 		= "Gas Bill";
$_data['text_10'] 		= "Electric Bill";
$_data['text_11'] 		= "Water Bill";
$_data['text_12'] 		= "Security Bill";
$_data['text_13'] 		= "Utility Bill";
$_data['text_14'] 		= "Other Bill";
$_data['text_15'] 		= "Total";
$_data['text_16'] 		= "Print Information";


?>