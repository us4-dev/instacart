<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Rental Collection Report";
$_data['text_2'] 		= "Report";
$_data['text_3'] 		= "Rental Collection Report Form";
$_data['text_4'] 		= "Select Floor";
$_data['text_5'] 		= "Select Unit";
$_data['text_6'] 		= "Select Month";
$_data['text_66'] 		= "Select Year";
$_data['text_7'] 		= "Submit";
$_data['text_8'] 		= "Payment Status";
$_data['text_88'] 		= "Select";
$_data['text_99'] 		= "Paid";
$_data['text_100'] 		= "Due";

$_data['validation'] 	= "Please select at least one or more fields";

?>