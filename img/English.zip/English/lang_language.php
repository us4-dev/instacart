<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "System Setup";
$_data['text_222'] 		= "Currency";
$_data['text_2'] 		= "Language";
$_data['text_22'] 		= "Email";
$_data['text_x33'] 		= "SMS";
$_data['text_3'] 		= "Select language";
$_data['text_4'] 		= "Settings Updated Successfully";

$_data['text_5'] 		= "Select Currency";
$_data['text_6'] 		= "Doller";
$_data['text_7'] 		= "Taka";
$_data['text_8'] 		= "--Select--";
$_data['text_9'] 		= "Dot (.)";
$_data['text_10'] 		= "Comma (,)";
$_data['text_11'] 		= "Left";
$_data['text_12'] 		= "Right";
$_data['text_14'] 		= "Currency Position";
$_data['text_144'] 		= "Currency Decimal";
$_data['text_15'] 		= "Currency Separator";
$_data['text_16'] 		= "Super Admin Image";
$_data['text_17'] 		= "Upload Language Zip File";
$_data['text_18'] 		= "Upload Zip File";
$_data['text_19'] 		= "Mail Protocol";
$_data['text_20'] 		= "Smtp Hostname";
$_data['text_21'] 		= "SMTP Username";
$_data['text_22x'] 		= "SMTP Password";
$_data['text_23'] 		= "SMTP Post";
$_data['text_24'] 		= "SMTP Secure";
$_data['text_25'] 		= "ClickATell Username";
$_data['text_26'] 		= "ClickATell Password";
$_data['text_27'] 		= "ClickATell API Key";

$_data['text_lang_1'] 	= "How to create and upload new language file :";
$_data['text_lang_2'] 	= "sample language file zip file.";
$_data['text_lang_22'] 	= "Download";
$_data['text_lang_3'] 	= "Unzip zip file then change all file text manually.";
$_data['text_lang_4'] 	= "Add 24x24px size language flag.png image.";
$_data['text_lang_5'] 	= "Rename folder name by your language name then make it zip and uplaod it via our language uploader.";
?>