<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 				= "Leave Request List"; 
$_data['text_1_1_1'] 			= "Leave Details";
$_data['text_2'] 				= "Leave";
$_data['text_2_2'] 				= "Employee Information";
$_data['text_3'] 				= "Add Leave request";
$_data['text_4'] 				= "Leave Request Entry Form";


$_data['requested_date'] 		= "Requested Date";
$_data['emp_name'] 				= "Name";
$_data['emp_designation'] 		= "Designation";

$_data['leave_from'] 			= "Leave From";
$_data['leave_to'] 				= "Leave To";
$_data['leave_days'] 			= "Days of Leave";
$_data['leave_status'] 			= "Leave Status";
$_data['leave_description'] 	= "Leave Details";

$_data['text_8'] 				= "Created leave request successfully wait for admin reply.";
$_data['text_9'] 				= "Updated Leave Request Successfully";
$_data['text_10'] 				= "Deleted Leave Request Successfully";
$_data['text_100'] 				= "Are you sure you want to delete this leave request ?";
$_data['text_11'] 				= "Month";
$_data['text_12'] 				= "Year";

$_data['t_text_1'] 				= "Employee Leave Request";

?>