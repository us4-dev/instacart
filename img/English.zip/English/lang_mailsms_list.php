<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['list_title'] 							= "Email / SMS List";
$_data['add_new_floor_information_breadcam'] 	= "Email/SMS";
$_data['delete_floor_information'] 				= "Deleted Notification Information Successfully.";
$_data['list_1'] 								= "Date";
$_data['list_2'] 								= "Subject";
$_data['list_3'] 								= "Message";
$_data['list_4'] 								= "Notification Type";
$_data['list_5'] 								= "Sender List";
$_data['add_sms'] 								= "Send Email / SMS";

$_data['text_1'] 								= "*Note: Select all users or sepecific user to send sms or email.";
$_data['text_2'] 								= "Message Subject";
$_data['text_3'] 								= "Message";

$_data['text_4'] 								= "All";
$_data['text_5'] 								= "Specific Tenant";
$_data['text_6'] 								= "Specific Owner";
$_data['text_7'] 								= "Specific Employee";

$_data['text_8'] 								= "Type Tenant Name Here...";
$_data['text_9'] 								= "Type Owner Name Here...";
$_data['text_10'] 								= "Type Employee Name Here...";
$_data['text_11'] 								= "Message Type";
$_data['text_12'] 								= "SMS";
$_data['text_13'] 								= "Email";
$_data['text_14'] 								= "SEND NOTIFICATION";
$_data['text_15'] 								= "CLOSE";
$_data['text_16'] 								= "Already Added";
$_data['text_17'] 								= "SMS and Email";

$_data['text_18'] 								= "Tenant";
$_data['text_19'] 								= "Owner";
$_data['text_20'] 								= "Employee";
$_data['text_21'] 								= "Before send email or sms you must setup your email and sms configuration from";
$_data['text_22'] 								= "Otherwise you cannot send email or sms.";
$_data['text_23'] 								= "here";

$_data['add_msg'] 								= "Added Notification Information Successfully";
$_data['update_msg'] 							= "Update Notification Information Successfully";
$_data['confirm'] 								= "Are you sure you want to delete this Notification ?";
?>