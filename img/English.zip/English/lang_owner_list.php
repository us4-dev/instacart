<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['owner_list'] 							 	= "Owner List ";
$_data['add_new_form_field_text_1'] 				= "Owner Name";
$_data['add_new_form_field_text_2'] 				= "Email ";
$_data['add_new_form_field_text_3'] 				= "Password";
$_data['add_new_form_field_text_4'] 				= "Contact";
$_data['add_new_form_field_text_5'] 				= "Present Address";
$_data['add_new_form_field_text_6'] 				= "Permanent Address";
$_data['add_new_form_field_text_7'] 				= "NID(National ID)";
$_data['add_new_form_field_text_8'] 				= "Owner Unit";
$_data['add_new_form_field_text_9'] 				= "Image";
$_data['add_new_owner_information_breadcam'] 		= "Owner Information";
$_data['add_new_owner_breadcam'] 					= "Add Owner";
$_data['added_owner_successfully'] 					= "Added Owner Information Successfully";
$_data['update_owner_successfully'] 				= "Updated Owner Information Successfully";
$_data['delete_owner_information'] 					= "Deleted Owner Information Successfully";
$_data['owner_details'] 							= "Owner Details";
$_data['confirm']									= "Are you sure you want to delete this Owner ?";


?>