<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 			= "Tenant Report";
$_data['text_2'] 			= "Report";
$_data['text_3'] 			= "Tenant Report Form";
$_data['text_4'] 			= "Select Tenant Status";
$_data['text_5'] 			= "Select";

$_data['text_active'] 		= "Active";
$_data['text_leave'] 		= "In-Active";


?>