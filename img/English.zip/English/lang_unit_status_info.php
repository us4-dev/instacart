<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Unit Status Report";
$_data['text_2'] 		= "Floor No";
$_data['text_3'] 		= "Unit No";
$_data['text_4'] 		= "Status";
$_data['text_5'] 		= "Booked";
$_data['text_6'] 		= "Available";

?>