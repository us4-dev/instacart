<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1_1'] 		= "Visitor List";
$_data['text_2'] 		= "Visitor";
$_data['text_3'] 		= "Add Visitor";
$_data['text_4'] 		= "Visitor Entry Form";
$_data['text_5'] 		= "Entry Date";
$_data['text_6'] 		= "Name";
$_data['text_7'] 		= "Mobile";
$_data['text_8'] 		= "Address";
$_data['text_9'] 		= "Floor No";
$_data['text_10'] 		= "Select Floor";
$_data['text_11'] 		= "Unit No";
$_data['text_12'] 		= "Select Unit";
$_data['text_13'] 		= "In Time";
$_data['text_14'] 		= "Out Time";
$_data['text_15'] 		= "Added Visitor Successfully";
$_data['text_16'] 		= "Update Visitor";
$_data['text_17'] 		= "Updated Visitor Successfully";
$_data['text_18'] 		= "Deleted Visitor Successfully";
$_data['text_19'] 		= "Are you sure you want to delete this Visitor ?";
?>